local function capitalize_first_letter(str)
    return str:sub(1, 1):upper() .. str:sub(2)
end

require("theprimeagen.remap")
local username = os.getenv("USERNAME") or "utente"
username = capitalize_first_letter(username)  -- Capitalizza la prima lettera
print("Benvenuto in nvim " .. username .. "! Buon lavoro!")

